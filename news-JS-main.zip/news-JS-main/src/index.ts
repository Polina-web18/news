import axios from 'axios';

interface NewsArticle {
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    publishedAt: string;
    author: string;
}

class NewsAPI {
    private apiUrl: string;
    private apiKey: string;

    constructor() {
        this.apiUrl = process.env.API_URL!;
        this.apiKey = process.env.API_KEY!;
    }

    public async fetchNews(): Promise<NewsArticle[]> {
        try {
            const response = await axios.get(`${this.apiUrl}top-headlines?country=us&apiKey=${this.apiKey}`);
            return response.data.articles;
        } catch (error) {
            console.error('Error fetching news:', error);
            return [];
        }
    }

    public async renderNews(): Promise<void> {
        const articles = await this.fetchNews();
        const newsContainer = document.querySelector('.news') as HTMLElement;

        articles.forEach(article => {
            const articleElement = document.createElement('div');
            articleElement.className = 'news__item';
            articleElement.innerHTML = `
                <div class="news__description">
                    <h2>${article.title}</h2>
                    <p>${article.description}</p>
                    <a href="${article.url}" target="_blank">Read More</a>
                </div>
            `;
            newsContainer?.appendChild(articleElement);
        });
    }
}

const newsAPI = new NewsAPI();
newsAPI.renderNews();